from machine import Pin
from time import sleep
from dht import DHT22
dht = DHT22(Pin(16))

while True:
    # getting sensor readings
    dht.measure()
    temp = dht.temperature()
    hum = dht.humidity()

    # displaying values to the console
    print(f"Temperature: {temp}°C   Humidity: {hum}% ")
        
    sleep(2)