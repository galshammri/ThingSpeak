from machine import Pin
from time import sleep

# creating a PIR object, setting it as IN
pir = Pin(10, Pin.IN)

# continuously read data from the PIR sensor
# print a status whether a motion or detected or not 
while True:
   if pir.value() == 1:
       print("Motion detected!")
   
   else:
       print("No Motion detected!")

    # PIR sensor would check for movement every second
   sleep(1)
