import network
from machine import Pin
from time import sleep
import dht
import urequests

print("Connecting to WiFi ...")
wifi = network.WLAN(network.STA_IF)
wifi.active(True)
wifi.connect("Wokwi-GUEST", "")
while not wifi.isconnected():
  sleep(0.5)
  print(".", end = "")
  sleep(0.1)
print(wifi.ifconfig())

sensor = dht.DHT22(Pin(15))
api_key = 'K6AD8IWLQFAZ9XS6'
while True:
  sensor.measure()
  temp = sensor.temperature()
  hum = sensor.humidity()
  url = f'http://api.thingspeak.com/update?api_key={api_key}&field1={temp}&field2={hum}'
  url_response = urequests.get(url)
  print(f'Temperature: {temp} Humidity: {hum}')
  sleep(5)