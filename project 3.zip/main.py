import machine
from machine import Pin
from time import sleep_us,sleep

echo=Pin(21,Pin.IN)
trig=Pin(20,Pin.OUT)
#x=machine.time_pulse_(echo,1)
#d=(0.0343*x)/2
while True:
    trig.value(0)
    sleep_us(2)
    trig.value(1)
    sleep_us(10)
    trig.value(0)
    
    x=machine.time_pulse_us(echo,1)
    distance=(0.034*x)/2 
    print('Distance:', distance, 'cm')
    sleep(1)